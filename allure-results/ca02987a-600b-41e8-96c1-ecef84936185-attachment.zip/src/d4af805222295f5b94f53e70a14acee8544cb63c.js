import { test, expect } from '../fixtures/GlobalFixture.js';

test.beforeEach("Precondition", async({page}) => {
    await page.goto("/");

     console.log('Current URL:', page.url());
    console.log('Page title:', await page.title());

    await page.screenshot({
        path: 'reports/debug-contact-page.png',
        fullPage: true
    });
});

test("@e2e @Regression Verify user is on Contact page", async({page, contactPage})=>{

    console.log(
        'Contact link count:',
        await contactPage.contactLink.count()
    );

    console.log(
        'Contact link visible:',
        await contactPage.contactLink.isVisible().catch(() => false)
    );

    await expect(contactPage.contactLink).toBeVisible({
        timeout: 10000
    });

    await contactPage.clickOnContactLink();

  //  await expect(page.url()).toContain("contacts");

    await expect(page).toHaveURL(/contacts/);
});

test("@e2e @Regression @Sanity create new contact", async({page, contactPage}) => {
    await contactPage.clickOnContactLink();

    await contactPage.clickOnCreateButton();

    await contactPage.enterFirstname("Pratiksha");

    await contactPage.enterLastname("Hundekar");

    await contactPage.enterEmail("pratiksha@gnail.com");

    await contactPage.clickOnSaveButton();
});

